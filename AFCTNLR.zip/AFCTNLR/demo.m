clear;
close all;
addpath(genpath('lib'));
addpath(genpath('data'));

%%
methodname    = {'Observed','FCTNLR','FCTNLRN'};%%'TT-TC','TR-TC','TRGR-TC',
Mnum          = length(methodname);
Re_tensor1     = cell(Mnum,1);
psnr1          = zeros(Mnum,1);
ssim1         = zeros(Mnum,1);
time1          = zeros(Mnum,1);


%% Load initial data
load('ukulele.mat')
X=double(X);
C=size(X);
if max(X(:))>1
     X = X/max(X(:));
end

%% Sampling with random position
sample_ratio = 0.03;
fprintf('=== The sample ratio is %4.2f ===\n', sample_ratio);
T         = X;
Ndim      = ndims(T);
Nway      = size(T);
rand('state',0);
Omega     = find(rand(prod(Nway),1)<sample_ratio);
data = X(Omega);
F         = zeros(Nway);
F(Omega)  = T(Omega);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i  = 1;
Re_tensor1{i} = F;
[psnr1(i), ssim1(i)] = quality_ybz(T*255, Re_tensor1{i}*255);
enList = 1;


%% Perform  algorithms
opts=[];
opts.tol   = 1e-9;
opts.Xtrue =T;
opts.maxit =300;
opts.R     = [0,  2,  2,  2;
              0,  0, 2,  2;
               0,  0,  0, 2;
              0,  0,  0,  0];
opts.max_R = [0,  40,  3,  10;
               0,  0,   3,  10;
               0,  0,   0, 3; 
               0,  0,   0,  0]; 

%% FCTNLR
% opts.maxit =300;
opts.rho   = 0.1;
opts.mul  =0.55;
opts.delta =0.60;
i=i+1;
t0= tic;
[Re_tensor1{i},G,Out]        = FCTNLRN_TC(F,Omega,opts);
time(i)                     = toc(t0);
[psnr1(i), ssim1(i)]          = quality_ybz(T*255, Re_tensor1{i}*255);
enList = [enList,i];
i=i+1;
t0= tic;
[Re_tensor1{i},G1,Out1]        = FCTNLR_TC(F,Omega,opts);
time(i)                     = toc(t0);
[psnr1(i), ssim1(i)]          = quality_ybz(T*255, Re_tensor1{i}*255);
enList = [enList,i];

%% Show result
fprintf('\n');
fprintf('================== Result =====================\n');
fprintf(' %20.20s    %5.4s    %5.4s   %5.4s \n','method','PSNR', 'SSIM','TIME' );
for i = 1:length(enList)
    fprintf(' %20.20s    %5.3f    %5.3f   %5.4s \n',...
    methodname{enList(i)},psnr1(enList(i)), ssim1(enList(i)),time(enList(i)));

end
fprintf('================== Result =====================\n');
%% visualization
k = 1:3;
numMethod = length(enList);
totalImg  = numMethod + 1;

figure('Color','w', ...
       'Position',[100 100 1600 300]);

tiledlayout(1,totalImg,'Padding','compact','TileSpacing','compact');

% original image
nexttile;
imshow(T(:,:,k),[]);
title('Original','FontSize',12,'FontWeight','bold');

% reconstructed images
for i = 1:numMethod
    nexttile;
    imshow(Re_tensor1{i}(:,:,k),[]);

    title(sprintf('%s\nPSNR=%.2f', ...
          methodname{enList(i)}, ...
          psnr1(enList(i))), ...
          'Interpreter','none', ...
          'FontSize',11);

end
