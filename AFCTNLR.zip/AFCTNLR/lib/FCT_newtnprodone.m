%==========================================================================
% Compute the FCTN composition of the factors (Definition 5 in the paper)
% Input:
function Out = FCT_newtnprodone(DD,G,Nway,j)
Nx = length(Nway);
if Nx == 4
    switch j
        case 1
            Out = G * DD;
            Out = reshape(Out, Nway);
        case 2
            Out = G * DD;
            idx = setdiff(1:Nx, j);
            Out = reshape(Out, [Nway(j), Nway(idx)]);
            Out = permute(Out, [2, 1, 3, 4]);
        case 3
            Out = DD' * G';
            idx = setdiff(1:Nx, j);
            Out = reshape(Out, [Nway(idx), Nway(j)]);
            Out = permute(Out, [1, 2, 4, 3]);
        case 4
            Out = DD' * G';
            Out = reshape(Out, Nway);
    end
else
    Out = DD' * G';
    Out = reshape(Out, Nway);
end
