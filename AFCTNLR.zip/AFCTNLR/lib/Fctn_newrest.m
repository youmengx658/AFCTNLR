function [Out,temptensor,n] = Fctn_newrest(G,rest)
N = length(G);
n = 1:N; 
n(rest)=[];   
if rest <= 2
    mm = n(1);     n(1) = [];
    firstOrder = true;
else
    mm = n(end);   n(end) = [];
    firstOrder = false;
end
temptensor = Fctn_contraction(G{n(1)}, G{n(2)}, n(2), n(1));
if firstOrder
    m = [mm, mm + 3];
    Out = Fctn_contraction(G{mm}, temptensor, n, m);
else
    m = [mm - 1, mm + 2];
    Out = Fctn_contraction(temptensor, G{mm}, m, n);
end



