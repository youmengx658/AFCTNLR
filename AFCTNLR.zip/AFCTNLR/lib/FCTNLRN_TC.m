function [X, G, Out] = FCTNLRN_TC(F,Omega,opts)
if isfield(opts, 'tol');         tol       = opts.tol;          end
if isfield(opts, 'maxit');       maxit     = opts.maxit;        end
if isfield(opts, 'rho');         rho       = opts.rho;          end
if isfield(opts, 'R');           R         = opts.R;            end
if isfield(opts, 'mul');          mu        = opts.mul;           end
if isfield(opts, 'max_R');       max_R     = opts.max_R;        end
if isfield(opts, 'delta');       delta     = opts.delta ;       end

rand('state',0);
N = ndims(F);
Nway = size(F);
X = F;

extrapolation=false;
tempdim = diag(Nway)+R+R';
max_tempdim = diag(Nway)+max_R+max_R';
kkk=true;

Sig2 = cell(1,N);
D = cell(1,N);
G = cell(1,N);
% Gu= cell(1,N);
for i = 1:N
    G{i}  = rand(tempdim(i,:));
    e = ones(Nway(i), 1); 
    D{i} = diag(-(2+delta)*e) + diag(e(1:end-1),1) + diag(e(1:end-1),-1);
    D{i}(1,end) = 1; 
    D{i}(end,1) = 1; 
    Sig2{i} = abs(fft(D{i}(:,1))).^2;
end

Out.Res = []; Out.PSNR = [];Out.Ssim = [];

r_change = 0.01;

for k = 1:maxit
    indeN = 1:N;
    if isequal(tempdim, max_tempdim)
       if kkk
          extrapolation=true;
          newindenN = 1:N;
          kkk=false;
       elseif N==4
          [newindenN(1),newindenN(2)]=deal(newindenN(2),newindenN(1));
          indeN=newindenN;
       end
    end    
    Xold = X;
    % Update G
    for i = 1:N
        j = indeN(1);
        Xi = my_Unfold(X, Nway, j);
        Unfold_G = my_Unfold(G{j}, tempdim(j,:), j);
        if N == 4
            if exist('temptensor', 'var')
                Girest = Fctn_reshape_new(Fctn_rest_newD(G, temptensor, j), N, j);
                indeN(indeN == j) = [];
                if ~isequal(tempdim, max_tempdim) || length(indeN) == 2
                    clear temptensor
                end
            else
                [tempGirest, temptensor] = Fctn_newrest(G, j);
                Girest = Fctn_reshape_new(tempGirest, N, j);
                indeN(indeN == j) = [];
            end
        else
            Girest = tnreshape(tnprod_rest(G, j), N, j);
            indeN(indeN == j) = [];
        end
        tempC = Xi * Girest' + rho * Unfold_G;
        [U1, S1, ~] = svd(Girest * Girest');
        if ~isempty(indeN)
           clear Girest
        end

        Sig1 = diag(S1);
        Sig = repmat(Sig1', Nway(j), 1) + ...
              repmat(mu * Sig2{j}, 1, prod(tempdim(j,:)) / Nway(j)) + rho;
        Sig = 1 ./ Sig;
        temp = Sig .* (fft(tempC) * U1);
        tempG = real(ifft(temp)) * U1';
        G{j} = my_Fold(tempG, tempdim(j,:), j);

        if extrapolation
            newindenN(end+1-i) = j;
        end
    end
    % Update X
    X = (FCT_newtnprodone(Girest,tempG,Nway,j)+rho*Xold)/(1+rho);
    clear Girest
    X(Omega) = F(Omega);
    %% check the convergence
    if isfield(opts, 'Xtrue')
        XT       = opts.Xtrue;
        PSNR     = psnr_ybz(XT*255,X*255);
        Out.PSNR = [Out.PSNR,PSNR];
    end
    clear XT
    res     = norm(X(:)-Xold(:))/norm(Xold(:));
    Out.Res = [Out.Res,res];
   
    if mod(k, 100) == 0  ||   k == 1
        if isfield(opts, 'Xtrue')
            fprintf('FCTNLR-TC: iter = %d   PSNR=%f   res=%f   \n', k, PSNR, res);
        else
            fprintf('FCTNLR-TC: iter = %d   res=%f   \n', k, res);
        end
    end
    if res < tol
        break;
    end 
  
    rank_inc = double(tempdim<max_tempdim);
    if res < r_change && sum(rank_inc(:)) ~= 0
        G = rank_inc_adaptive(G,rank_inc,N);
        tempdim = tempdim+rank_inc;
    end
end
end

function G = rank_inc_adaptive(G,rank_inc,N)
% increase the estimated rank
for j = 1:N
    G{j} = padarray(G{j},rank_inc(j,:),rand(1),'post');
end
end


    
    

