function [X, G, Out] = FCTNLR_TC(F,Omega,opts)
if isfield(opts, 'tol');         tol       = opts.tol;          end
if isfield(opts, 'maxit');       maxit     = opts.maxit;        end
if isfield(opts, 'rho');         rho       = opts.rho;          end
if isfield(opts, 'R');           R         = opts.R;            end
if isfield(opts, 'mul');         mu        = opts.mul;          end
if isfield(opts, 'max_R');       max_R     = opts.max_R;        end
% if isfield(opts, 'etr');         etr     = opts.etr;            end
if isfield(opts, 'delta');       delta     = opts.delta ;       end

rand('state',0)
N = ndims(F);
Nway = size(F);
X = F;
% extrapolation=false;
tempdim = diag(Nway)+R+R';
max_tempdim = diag(Nway)+max_R+max_R';

Sig2 = cell(1,N);
D = cell(1,N);
G = cell(1,N);
for i = 1:N
    G{i}  = rand(tempdim(i,:));
    e = ones(Nway(i), 1); 
    D{i} = diag(-(2+delta)*e) + diag(e(1:end-1),1) + diag(e(1:end-1),-1);
    D{i}(1,end) = 1; 
    D{i}(end,1) = 1; 
    d = D{i}(:,1);
    deig = fft(d);
    Sig2{i} = abs(deig).^2;
end
Out.Res = []; Out.PSNR = []; Out.Ssim = [];iter_time = [];  
r_change = 0.01;

% total_start = tic;
for k = 1:maxit 
    Xold = X;
    %% Update G
    for i = 1:N
        Xi = my_Unfold(X,Nway,i);
        Unfold_G = my_Unfold(G{i},tempdim(i,:),i);
    %% Compute Girest
        if N == 4
            if exist('temptensor', 'var')
                Girest = Fctn_reshape_new(Fctn_rest_newD(G, temptensor, i), N, i);
                clear temptensor;
            else
                [tempGirest, temptensor] = Fctn_newrest(G, i);
                Girest = Fctn_reshape_new(tempGirest, N, i);
            end
        else
            Girest = tnreshape(tnprod_rest(G, i), N, i);
        end
        tempC = Xi*Girest'+rho*Unfold_G;
        [U1,S1,~] = svd(Girest*Girest',"econ"); 
        if i~=N
            clear Girest
        end
        Sig1    = diag(S1);
        Sig     = repmat(Sig1',Nway(i),1)+repmat(mu*Sig2{i},1,prod(tempdim(i,:))/Nway(i))+rho;
        Sig     = 1./Sig;
        temp    = Sig.*(fft(tempC)*U1);
        tempG   = real(ifft(temp))*U1';
        G{i}    = my_Fold(tempG,tempdim(i,:),i);
    end
    %% Update X
    X = (FCT_tnprodone(Girest,tempG,Nway)+rho*Xold)/(1+rho);
    X(Omega) = F(Omega);
    %% check the convergence
    if isfield(opts, 'Xtrue')
        XT       = opts.Xtrue;
        PSNR     = psnr_ybz(XT*255,X*255);
        Out.PSNR = [Out.PSNR,PSNR];
    end
    res     = norm(X(:)-Xold(:))/norm(Xold(:));
    Out.Res = [Out.Res,res];
    if mod(k, 100) == 0  ||   k == 1
        if isfield(opts, 'Xtrue')
            fprintf('FCTNLR-TC: iter = %d   PSNR=%f   res=%f   \n', k, PSNR, res);
        else
            fprintf('FCTNLR-TC: iter = %d   res=%f   \n', k, res);
        end
        % fprintf('FCTNLR-TC: iter = %d   res=%f   \n', k, res);
    end
    if res < tol
        break;
    end 
  
    rank_inc = double(tempdim<max_tempdim);
    if res < r_change && sum(rank_inc(:)) ~= 0
        G = rank_inc_adaptive(G,rank_inc,N);
        tempdim = tempdim+rank_inc;
    end

    % if k == 100 || k == 300 || k == 500
    %     if isfield(opts, 'Xtrue')
    %         XT       = opts.Xtrue;
    %         PSNR     = psnr_ybz(XT*255,X*255);
    %         Out.PSNR = [Out.PSNR,PSNR];
    %     end 
    %     curr_time = toc(total_start);
    %     iter_time = [iter_time; k, curr_time];
    %     fprintf('--> Iter %d total elapsed time: %.4f s\n', k, curr_time);
    % end
end
Out.iter_time = iter_time;
end
function G = rank_inc_adaptive(G,rank_inc,N)
%% increase the estimated rank
for j = 1:N
    G{j} = padarray(G{j},rank_inc(j,:),rand(1),'post');
end
end


    
    

