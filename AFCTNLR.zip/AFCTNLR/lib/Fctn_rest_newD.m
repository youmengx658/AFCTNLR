function Out = Fctn_rest_newD(G, Y, i)
if i <= 2
    kkk = [1, 2];  ddd = [3, 4];
    contractY = [kkk(kkk ~= i), kkk(kkk ~= i) + 3];
    firstOrder = true;
else
    kkk = [3, 4];  ddd = [1, 2];
    contractY = [kkk(kkk ~= i) - 1, kkk(kkk ~= i) + 2];
    firstOrder = false;
end

X = G{kkk(kkk ~= i)};
Lx = size(X);
Ly = size(Y);
indexx = setdiff(1:ndims(X), ddd);
indexy = 1:ndims(Y);
remainY = setdiff(indexy, contractY);

if firstOrder
    orderX = [indexx, ddd];
    orderY = [contractY, remainY];
    shapeX = [prod(Lx(indexx)), prod(Lx(ddd))];
    shapeY = [prod(Ly(contractY)), prod(Ly(remainY))];
    outShape = [Lx(indexx), Ly(remainY)];
    tempOut = reshape(permute(X, orderX), shapeX) * ...
              reshape(permute(Y, orderY), shapeY);
else
    orderX = [ddd, indexx];
    orderY = [remainY, contractY];
    shapeX = [prod(Lx(ddd)), prod(Lx(indexx))];
    shapeY = [prod(Ly(remainY)), prod(Ly(contractY))];
    outShape = [Ly(remainY), Lx(indexx)];
    tempOut = reshape(permute(Y, orderY), shapeY) * ...
              reshape(permute(X, orderX), shapeX);
end

Out = reshape(tempOut, outShape);
end

  

